import { useState, useRef } from "react"

export default function App() {
  const [file, setFile] = useState(null)
  const [email, setEmail] = useState("")
  const [status, setStatus] = useState("idle")
  const [message, setMessage] = useState("")
  const [preview, setPreview] = useState("")
  const [dragging, setDragging] = useState(false)
  const fileRef = useRef()

  const handleDrop = (e) => {
    e.preventDefault()
    setDragging(false)
    const dropped = e.dataTransfer.files[0]
    if (dropped && (dropped.name.endsWith(".csv") || dropped.name.endsWith(".xlsx"))) {
      setFile(dropped)
    }
  }

  const handleSubmit = async () => {
    if (!file || !email) return
    setStatus("loading")
    setMessage("")
    setPreview("")

    const formData = new FormData()
    formData.append("file", file)
    formData.append("email", email)

    try {
      const res = await fetch(`${import.meta.env.VITE_API_URL}/api/analyze`, {
        method: "POST",
        headers: { "X-API-Key": import.meta.env.VITE_API_KEY || "dev-secret-key" },
        body: formData,
      })

      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || "Something went wrong")

      setStatus("success")
      setMessage(data.message)
      setPreview(data.summary_preview)
    } catch (err) {
      setStatus("error")
      setMessage(err.message)
    }
  }

  const reset = () => {
    setFile(null)
    setEmail("")
    setStatus("idle")
    setMessage("")
    setPreview("")
  }

  return (
    <div style={styles.page}>
      {/* Background grid */}
      <div style={styles.grid} />

      <div style={styles.card}>
        {/* Logo / Header */}
        <div style={styles.header}>
          <div style={styles.logo}>R</div>
          <div>
            <h1 style={styles.title}>Rabbitt AI</h1>
            <p style={styles.subtitle}>Sales Insight Automator</p>
          </div>
        </div>

        <p style={styles.desc}>
          Upload your sales data → AI generates an executive summary → Delivered to your inbox instantly.
        </p>

        {status !== "success" ? (
          <>
            {/* File Drop Zone */}
            <div
              style={{ ...styles.dropzone, ...(dragging ? styles.dropzoneDrag : {}), ...(file ? styles.dropzoneFilled : {}) }}
              onDragOver={(e) => { e.preventDefault(); setDragging(true) }}
              onDragLeave={() => setDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileRef.current.click()}
            >
              <input
                ref={fileRef}
                type="file"
                accept=".csv,.xlsx"
                style={{ display: "none" }}
                onChange={(e) => setFile(e.target.files[0])}
              />
              {file ? (
                <div style={styles.fileInfo}>
                  <span style={styles.fileIcon}>📄</span>
                  <div>
                    <p style={styles.fileName}>{file.name}</p>
                    <p style={styles.fileSize}>{(file.size / 1024).toFixed(1)} KB</p>
                  </div>
                  <button
                    style={styles.removeBtn}
                    onClick={(e) => { e.stopPropagation(); setFile(null) }}
                  >✕</button>
                </div>
              ) : (
                <div style={styles.dropText}>
                  <span style={{ fontSize: "32px" }}>☁️</span>
                  <p style={{ margin: "8px 0 4px", color: "#ccc", fontWeight: "600" }}>
                    Drop your file here
                  </p>
                  <p style={{ margin: 0, color: "#666", fontSize: "13px" }}>
                    or click to browse · .csv or .xlsx
                  </p>
                </div>
              )}
            </div>

            {/* Email Input */}
            <div style={styles.inputGroup}>
              <label style={styles.label}>Recipient Email</label>
              <input
                type="email"
                placeholder="executive@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                style={styles.input}
                onFocus={(e) => e.target.style.borderColor = "#6C63FF"}
                onBlur={(e) => e.target.style.borderColor = "#2a2a3e"}
              />
            </div>

            {/* Submit Button */}
            <button
              onClick={handleSubmit}
              disabled={status === "loading" || !file || !email}
              style={{
                ...styles.btn,
                ...((!file || !email) ? styles.btnDisabled : {}),
                ...(status === "loading" ? styles.btnLoading : {})
              }}
            >
              {status === "loading" ? (
                <span style={styles.spinner}>
                  <span style={styles.spinnerDot} />
                  Analyzing your data...
                </span>
              ) : (
                "🚀 Generate & Send Summary"
              )}
            </button>

            {/* Error State */}
            {status === "error" && (
              <div style={styles.errorBox}>
                <span>❌</span>
                <p style={{ margin: 0 }}>{message}</p>
              </div>
            )}
          </>
        ) : (
          /* Success State */
          <div style={styles.successBox}>
            <div style={styles.successIcon}>✅</div>
            <h2 style={{ color: "#4ade80", margin: "0 0 8px" }}>Summary Sent!</h2>
            <p style={{ color: "#aaa", margin: "0 0 20px", fontSize: "14px" }}>{message}</p>

            <div style={styles.previewBox}>
              <p style={styles.previewLabel}>Preview</p>
              <p style={styles.previewText}>{preview}</p>
            </div>

            <button onClick={reset} style={styles.resetBtn}>
              ↩ Analyze Another File
            </button>
          </div>
        )}

        <p style={styles.footer}>
          Powered by Groq · Llama 3 · Resend
        </p>
      </div>
    </div>
  )
}

const styles = {
  page: {
    minHeight: "100vh",
    background: "#080810",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "20px",
    position: "relative",
    overflow: "hidden",
  },
  grid: {
    position: "fixed",
    inset: 0,
    backgroundImage: `
      linear-gradient(rgba(108,99,255,0.05) 1px, transparent 1px),
      linear-gradient(90deg, rgba(108,99,255,0.05) 1px, transparent 1px)
    `,
    backgroundSize: "40px 40px",
    pointerEvents: "none",
  },
  card: {
    background: "#10101e",
    border: "1px solid #1e1e35",
    borderRadius: "16px",
    padding: "40px",
    width: "100%",
    maxWidth: "480px",
    position: "relative",
    boxShadow: "0 0 60px rgba(108,99,255,0.08)",
  },
  header: {
    display: "flex",
    alignItems: "center",
    gap: "14px",
    marginBottom: "16px",
  },
  logo: {
    width: "44px",
    height: "44px",
    background: "linear-gradient(135deg, #6C63FF, #4facfe)",
    borderRadius: "10px",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    color: "#fff",
    fontWeight: "900",
    fontSize: "20px",
    fontFamily: "Georgia, serif",
  },
  title: {
    margin: 0,
    color: "#ffffff",
    fontSize: "20px",
    fontWeight: "700",
    fontFamily: "Georgia, serif",
  },
  subtitle: {
    margin: 0,
    color: "#6C63FF",
    fontSize: "12px",
    fontWeight: "600",
    letterSpacing: "1px",
    textTransform: "uppercase",
  },
  desc: {
    color: "#666",
    fontSize: "13px",
    lineHeight: "1.6",
    marginBottom: "28px",
    borderLeft: "2px solid #6C63FF",
    paddingLeft: "12px",
  },
  dropzone: {
    border: "2px dashed #2a2a3e",
    borderRadius: "10px",
    padding: "28px",
    textAlign: "center",
    cursor: "pointer",
    marginBottom: "20px",
    transition: "all 0.2s",
    background: "#0c0c1a",
  },
  dropzoneDrag: {
    borderColor: "#6C63FF",
    background: "#13132a",
  },
  dropzoneFilled: {
    borderColor: "#4ade80",
    borderStyle: "solid",
    background: "#0a1a0f",
  },
  dropText: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    gap: "4px",
  },
  fileInfo: {
    display: "flex",
    alignItems: "center",
    gap: "12px",
    textAlign: "left",
  },
  fileIcon: { fontSize: "28px" },
  fileName: { margin: 0, color: "#4ade80", fontWeight: "600", fontSize: "14px" },
  fileSize: { margin: 0, color: "#666", fontSize: "12px" },
  removeBtn: {
    marginLeft: "auto",
    background: "none",
    border: "none",
    color: "#666",
    cursor: "pointer",
    fontSize: "16px",
    padding: "4px 8px",
  },
  inputGroup: { marginBottom: "24px" },
  label: {
    display: "block",
    color: "#888",
    fontSize: "12px",
    fontWeight: "600",
    letterSpacing: "0.5px",
    textTransform: "uppercase",
    marginBottom: "8px",
  },
  input: {
    width: "100%",
    padding: "12px 14px",
    background: "#0c0c1a",
    border: "1px solid #2a2a3e",
    borderRadius: "8px",
    color: "#fff",
    fontSize: "14px",
    outline: "none",
    transition: "border-color 0.2s",
    boxSizing: "border-box",
  },
  btn: {
    width: "100%",
    padding: "14px",
    background: "linear-gradient(135deg, #6C63FF, #4facfe)",
    border: "none",
    borderRadius: "8px",
    color: "#fff",
    fontSize: "15px",
    fontWeight: "700",
    cursor: "pointer",
    transition: "opacity 0.2s",
    letterSpacing: "0.3px",
  },
  btnDisabled: { opacity: 0.4, cursor: "not-allowed" },
  btnLoading: { opacity: 0.8, cursor: "not-allowed" },
  spinner: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "10px",
  },
  spinnerDot: {
    width: "14px",
    height: "14px",
    border: "2px solid rgba(255,255,255,0.3)",
    borderTopColor: "#fff",
    borderRadius: "50%",
    animation: "spin 0.8s linear infinite",
    display: "inline-block",
  },
  errorBox: {
    display: "flex",
    alignItems: "center",
    gap: "10px",
    marginTop: "16px",
    padding: "14px",
    background: "#1a0a0a",
    border: "1px solid #4a1010",
    borderRadius: "8px",
    color: "#ff6b6b",
    fontSize: "14px",
  },
  successBox: {
    textAlign: "center",
    padding: "10px 0",
  },
  successIcon: { fontSize: "48px", marginBottom: "12px" },
  previewBox: {
    background: "#0c0c1a",
    border: "1px solid #1e1e35",
    borderRadius: "8px",
    padding: "16px",
    marginBottom: "20px",
    textAlign: "left",
  },
  previewLabel: {
    margin: "0 0 8px",
    color: "#6C63FF",
    fontSize: "11px",
    fontWeight: "700",
    letterSpacing: "1px",
    textTransform: "uppercase",
  },
  previewText: {
    margin: 0,
    color: "#888",
    fontSize: "13px",
    lineHeight: "1.7",
  },
  resetBtn: {
    padding: "11px 24px",
    background: "none",
    border: "1px solid #2a2a3e",
    borderRadius: "8px",
    color: "#aaa",
    cursor: "pointer",
    fontSize: "14px",
  },
  footer: {
    margin: "24px 0 0",
    color: "#333",
    fontSize: "11px",
    textAlign: "center",
    letterSpacing: "0.5px",
  },
}
