from fastapi import Header, HTTPException
import os

async def verify_api_key(x_api_key: str = Header(...)):
    expected = os.getenv("INTERNAL_API_KEY", "dev-secret-key")
    if x_api_key != expected:
        raise HTTPException(status_code=401, detail="Invalid API Key")
    return x_api_key
