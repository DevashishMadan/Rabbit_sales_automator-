from pydantic import BaseModel

class AnalyzeResponse(BaseModel):
    success: bool
    message: str
    summary_preview: str
