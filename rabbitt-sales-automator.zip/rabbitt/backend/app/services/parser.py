import pandas as pd
from fastapi import UploadFile, HTTPException
import io

async def parse_file(file: UploadFile) -> str:
    content = await file.read()

    try:
        if file.filename.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(content))
        elif file.filename.endswith(".xlsx"):
            df = pd.read_excel(io.BytesIO(content))
        else:
            raise HTTPException(400, "Only .csv or .xlsx files are allowed")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(400, f"Could not parse file: {str(e)}")

    if df.empty:
        raise HTTPException(400, "The uploaded file is empty")

    # Limit rows to avoid token overflow
    df = df.head(500)

    data_summary = f"""
DATASET OVERVIEW:
- Total Rows: {len(df)}
- Columns: {list(df.columns)}

STATISTICAL SUMMARY:
{df.describe().to_string()}

SAMPLE DATA (first 10 rows):
{df.head(10).to_string()}
    """
    return data_summary
