from groq import Groq
import os

client = Groq(api_key=os.getenv("GROQ_API_KEY"))

async def generate_summary(data_str: str) -> str:
    prompt = f"""
You are a senior business analyst at Rabbitt AI preparing a report for executive leadership.

Analyze the sales data below and write a professional executive summary with these sections:

1. **Performance Overview** - 2-3 sentence snapshot of the data
2. **Top 3 Key Insights** - most important findings
3. **Trends & Anomalies** - what stands out
4. **Recommendations** - 2 actionable suggestions for leadership
5. **Closing** - one sentence wrap-up

Keep it under 400 words. Be specific with numbers from the data. Professional tone.

SALES DATA:
{data_str}
    """

    response = client.chat.completions.create(
        model="llama3-70b-8192",
        messages=[{"role": "user", "content": prompt}],
        max_tokens=1000,
        temperature=0.4
    )

    return response.choices[0].message.content
