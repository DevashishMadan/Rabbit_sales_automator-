from fastapi import APIRouter, UploadFile, File, Form, Depends, Request
from slowapi import Limiter
from slowapi.util import get_remote_address
from app.services.parser import parse_file
from app.services.llm import generate_summary
from app.services.mailer import send_email
from app.middleware.security import verify_api_key
from app.models.schemas import AnalyzeResponse
from pydantic import EmailStr

router = APIRouter()
limiter = Limiter(key_func=get_remote_address)

@router.post(
    "/analyze",
    response_model=AnalyzeResponse,
    summary="Upload sales file and get AI summary via email",
    description="Upload a .csv or .xlsx file with sales data. An AI-generated executive summary will be sent to the provided email address.",
    dependencies=[Depends(verify_api_key)]
)
@limiter.limit("5/minute")
async def analyze(
    request: Request,
    file: UploadFile = File(..., description="Sales data file (.csv or .xlsx)"),
    email: str = Form(..., description="Recipient email address")
):
    # Step 1: Parse the uploaded file
    data_str = await parse_file(file)

    # Step 2: Generate AI summary via Groq
    summary = await generate_summary(data_str)

    # Step 3: Send email via Resend
    await send_email(email, summary)

    return AnalyzeResponse(
        success=True,
        message=f"Summary successfully sent to {email}",
        summary_preview=summary[:300] + "..."
    )
