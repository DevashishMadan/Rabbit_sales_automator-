# 📊 Rabbitt AI — Sales Insight Automator

> Upload CSV/XLSX → AI generates executive summary → Delivered to inbox instantly.

---

## 🚀 Quick Start (Local with Docker)

### 1. Clone the repo
```bash
git clone https://github.com/your-username/rabbitt-sales-automator
cd rabbitt-sales-automator
```

### 2. Set up environment variables
```bash
cp .env.example .env
# Now open .env and fill in your API keys
```

### 3. Get your API keys (all free)
| Service | Where to get it | What it does |
|---------|----------------|--------------|
| Groq | [console.groq.com](https://console.groq.com) | AI summary generation |
| Resend | [resend.com](https://resend.com) | Email delivery |
| Internal API Key | Run `openssl rand -hex 32` | Protects your API |

### 4. Run everything with one command
```bash
docker-compose up --build
```

### 5. Open the app
- **Frontend** → http://localhost:3000
- **Swagger API Docs** → http://localhost:8000/docs

---

## 🏗️ Project Structure

```
rabbitt-sales-automator/
├── backend/
│   ├── app/
│   │   ├── main.py              # FastAPI app
│   │   ├── routes/analyze.py    # POST /api/analyze
│   │   ├── services/
│   │   │   ├── parser.py        # CSV/XLSX parsing
│   │   │   ├── llm.py           # Groq AI summary
│   │   │   └── mailer.py        # Resend email
│   │   ├── middleware/
│   │   │   └── security.py      # API key auth
│   │   └── models/schemas.py    # Pydantic models
│   ├── Dockerfile
│   └── requirements.txt
├── frontend/
│   ├── src/App.jsx              # Single page UI
│   ├── Dockerfile
│   └── package.json
├── docker-compose.yml
├── .env.example
└── .github/workflows/ci.yml     # GitHub Actions
```

---

## 🔐 Security Overview

| Layer | What we did |
|-------|-------------|
| **API Key Auth** | Every request needs `X-API-Key` header. Wrong key → 401 |
| **Rate Limiting** | Max 5 requests/minute per IP (via slowapi). Prevents abuse |
| **CORS** | Only whitelisted frontend origins allowed |
| **File Validation** | Only .csv and .xlsx accepted. 500 row limit prevents token overflow |
| **Input Validation** | Email validated with Pydantic. Bad input → 422 |

---

## ☁️ Deploying to Production

### Backend → Render
1. Go to [render.com](https://render.com) → New Web Service
2. Connect your GitHub repo
3. Set root directory: `backend`
4. Build command: `pip install -r requirements.txt`
5. Start command: `uvicorn app.main:app --host 0.0.0.0 --port 8000`
6. Add your env variables in Render dashboard

### Frontend → Vercel
1. Go to [vercel.com](https://vercel.com) → New Project
2. Connect your GitHub repo
3. Set root directory: `frontend`
4. Add env variables:
   - `VITE_API_URL` = your Render backend URL
   - `VITE_API_KEY` = your INTERNAL_API_KEY value
5. Deploy

### After deploying
Update CORS in `backend/app/main.py`:
```python
allow_origins=["https://your-app.vercel.app"]
```

---

## 📡 API Reference

**POST** `/api/analyze`

| Field | Type | Description |
|-------|------|-------------|
| `file` | File | .csv or .xlsx sales data |
| `email` | String | Recipient email address |
| `X-API-Key` | Header | Your internal API key |

**Response:**
```json
{
  "success": true,
  "message": "Summary successfully sent to executive@company.com",
  "summary_preview": "Performance Overview: ..."
}
```

Full interactive docs at: `https://your-backend.onrender.com/docs`

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React + Vite |
| Backend | FastAPI (Python) |
| AI | Groq — Llama 3 70B |
| Email | Resend |
| Containers | Docker + docker-compose |
| CI/CD | GitHub Actions |
| Hosting | Vercel + Render |
